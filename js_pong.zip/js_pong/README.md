js-pong
=======

Canvas 2D Ping-pong, two players.

How to use, open html, use W, S - to move first pad Up, Down.

Take your friend to computer and give him mouse to control second pad.

First Commit:

- Added sound (new round, padle collision)
- Added Collision Detection (Simple - need to rework).
- Added Round functional, startscreen
- Added controls (W, S - for first padle, mousemove for second).

